adasdasd#include<stdio.h>
int main()
{
    int n, i , j, count=0;

    printf("Enter number: ");
    scanf("%d", &n);

    jump:
    for(i=4; i<=n;) // 4 ki 13 thike choto?
    {
        j = 2;
        printf("point");

        jj:
        while(j < i) //2 ki 4 thike choto?
        {
            if(i % j == 0) //4 ke ki 2 diye bhag kora jay?
            {
                i++;
                printf("destination");
                goto jump;
            }
            else
            {
                j++;
                goto jj;
            }
        }
    }
}
