//If both bits are 1, the result is 1.
//If at least one of the bits is 0, the result is 0.
//It is denoted by &.

//The result of the OR operation is 1
//if any of the bits being compared is 1.
//It's only 0 if both bits are 0. It is denoted by |.

//The result of bitwise XOR operator is
//1 if the corresponding bits of two
//operands are opposite. It is denoted by ^.

//Bitwise complement operator is a unary
//operator (works on only one operand). It
//changes 1 to 0 and 0 to 1. It is denoted by ~.

//5 = 101
//5 = 101 & 101
//        | 101
//        ^ 000
#include<stdio.h>

int main()
{

    int a=5, b=5, c;

    c = a&b;
    printf("%d\n", c);

    c = a|b;
    printf("%d\n", c);

    c=a^b;
    printf("%d\n", c);

    a = -5;
    c=~a;
    printf("%d",c);

}
