#include<stdio.h>
int main()
{
    int a,num1,num2,m;
    printf("1 = Multiplication\n2 = Division\n3 = Subtraction\n4 = Addition\n");
    scanf("%d",&a);

    switch(a)
    {
    case 1:
        printf("Enter two numbers: ");
        scanf("%d %d",&num1,&num2);
        m = num1 * num2;
        break;
    case 2:
        printf("Enter two numbers: ");
        scanf("%d %d",&num1,&num2);
        m = num1 / num2;
        break;
    case 3:
        printf("Enter two numbers: ");
        scanf("%d %d",&num1,&num2);
        m = num1 - num2;
        break;
    case 4:
        printf("Enter two numbers: ");
        scanf("%d %d",&num1,&num2);
        m = num1 + num2;
        break;
    }
    printf("Answer: %d", m );
}
