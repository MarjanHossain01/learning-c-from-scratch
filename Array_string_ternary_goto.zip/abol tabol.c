#include<graphics.h>
int main(){
}
