#include<stdio.h>
int main()
{
    int amogus[2] = {};
    scanf("%d ",&amogus);
    printf("%d ",amogus[2]);

}
