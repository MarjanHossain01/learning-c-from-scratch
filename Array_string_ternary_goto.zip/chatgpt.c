#include <stdio.h>

int main() {
    int n;

    printf("Enter a number: ");
    scanf("%d", &n);

    printf("Prime numbers less than or equal to %d are: ", n);

    for (int i = 2; i <= n; i++) {
        int isPrime = 1;  // Assume the number is prime

        // Check if i is not prime
        for (int j = 2; j * j <= i; j++) {
            if (i % j == 0) {
                isPrime = 0;  // It's not prime
                break;
            }
        }

        if (isPrime) {
            printf("%d ", i);
        }
    }

    printf("\n");

    return 0;
}
