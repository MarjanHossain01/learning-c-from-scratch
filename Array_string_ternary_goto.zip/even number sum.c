#include<stdio.h>
int main()
{
    int n,i=1,s=0;
    printf("Enter number Range: ");
    scanf("%d", &n);

    while(i<=n)
    {

        switch(i%2)
        {
        case 0:
            printf("%d ",i);
            s += i;
            break;
        }

        i++;
    }
    printf("\nSum: %d",s);
}
