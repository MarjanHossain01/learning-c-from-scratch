#include<stdio.h>
int main(){

    int n,i;
    int div[20];

    printf("Enter number: ");
    scanf("%d",&n);
    printf("Numbers: ");
    for(i=2; i<n; i++)
    {
        if(n % i == 0){
            div[20] = i;
            printf("%d ", div[20]);
        }
    }

}
