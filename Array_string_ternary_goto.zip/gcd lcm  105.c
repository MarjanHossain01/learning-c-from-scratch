#include<stdio.h>
int main()
{
    int num1, num2, i, gcd, lcm;
    printf("Enter 2 numbers: \n");
    scanf("%d %d", &num1, &num2);

    for(i=2; i<=num1; i++)
    {
        if(num1 % i == 0 && num2 % i == 0 )
        {
            gcd = i;
        }
    }
    lcm = (num1 * num2)/gcd;

    printf("LCM: %d\n",lcm);
    printf("GCD: %d",gcd);
}
