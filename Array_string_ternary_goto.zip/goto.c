#include<stdio.h>
int main()
{
    int i;

    jump:
    i = 5;
    printf("%d",i);
    goto jump;
}
