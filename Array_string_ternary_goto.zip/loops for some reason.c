#include<stdio.h>
int main()
{
    char a,b;
    printf("Enter Character: ");
    scanf("%c", &a);

    if (a >= 'a' && a <= 'z') {
        printf("%c", a-32);
    }
}
