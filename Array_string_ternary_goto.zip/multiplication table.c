#include<stdio.h>
int main()
{
    int n,i,c;
    jump:
    printf("Enter number: ");
    scanf("%d", &n);
    for(i=1; i<=10; i++)
    {
        printf("%d x %d = %d\n",n,i, n*i);
    }

    printf("Continue?\nYes: 1\nNo: 2\nw");
    scanf("%d",&c);
    if(c == 1){
        goto jump;
    }
}
