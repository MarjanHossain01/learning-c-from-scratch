#include<stdio.h>
int main(){
    int myAge;
    printf("%p", &myAge);
}
