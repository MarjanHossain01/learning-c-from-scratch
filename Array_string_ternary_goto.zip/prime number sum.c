#include<stdio.h>
int main()
{
    int n,i,j;
    int arr[50];
    int a=0;

    printf("Enter number: ");
    scanf("%d",&n);
    for(i=3; i<n; i++){
        for(j=2; j<i; j++){
             if(i % j == 0){
                arr[a] = i;
                a++;
             }
        }
    }
    printf("%d ",arr);
}
