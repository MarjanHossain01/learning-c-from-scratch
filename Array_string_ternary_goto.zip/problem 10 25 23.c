#include<stdio.h>
#include<string.h>
int main()
{
    int count=0,i,j;

    char first[20];
    char second[20];

    printf("Enter first word: ");
    scanf("%[^\n]%*c", first);
    printf("Enter second word: ");
    scanf("%s", &second);

    i = strlen(first)-1; // index
    j = strlen(second)-1;

    while(second[j]){
        if(first[i] != second[j]){
            count++;
            break;
        }
        i--;
        j--;
    }

    if(count == 0)
        printf("Same");
    else
        printf("I drive");

}
