//vowel count
#include<stdio.h>
#include <math.h>
int main()
{
    int n,s,i;
    printf("Enter Number: ");
    scanf("%d",&n); //1234
    printf("Print number %d\n",n);
    while(n != 0) {
        int newnum = n % 10;
        printf("%d\n",newnum);
        printf("Updated: %d\n",n);
        n = floor(n / 10);
    }

}
