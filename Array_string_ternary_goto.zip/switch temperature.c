#include<stdio.h>
int main ()
{
    int a,f,c;
    printf("1 = Fahrenheit to Celsius\n2 = Celsius to Fahrenheit\n");
    scanf("%d",&a);
    switch(a)
    {
    case 1:
        printf("Enter Fahrenheit: ");
        scanf("%d",&f);
        c = (f-32)*5/9;
        printf("Celsius: %d", c);
        break;
    case 2:
        printf("Enter Celsius: ");
        scanf("%d",&c);
        f = (c*9/5)+32;
        printf("Fahrenheit: %d", f);
        break;
    default:
        printf("Entered number is not 1 or 2. Program is Terminated");
        break;
    }
    getch();
}
