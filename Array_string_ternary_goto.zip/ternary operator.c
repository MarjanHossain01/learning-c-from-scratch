#include<stdio.h>
int main()
{
    int age;
    scanf("%d",&age);
    (age > 18) ? printf("Yes Edp") : printf("No Edp");
}
