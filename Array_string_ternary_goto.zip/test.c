#include<stdio.h>
int main()
{
    int i, n=10;
    i = n;
    printf("%d",i);

}
