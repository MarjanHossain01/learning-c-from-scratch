#include<stdio.h>
int main()
{
    int n,remainder,sum=0,count=0;
    printf("Enter a Number: ");
    scanf("%d",&n);

    int temp = n, digit = n;

    while(digit != 0){
        digit = digit / 10;
        ++count;
    }

    while(temp != 0){
        remainder = temp % 10;
        sum = 0 + remainder * count;
        temp = temp / 10;
    }

    if(sum == n){
        printf("Armstrong");
    }
    else
        printf("Not Armstrong");
}
