#include<stdio.h>
int main()
{
    int n,reverse;
    printf("Enter number: ");
    scanf("%d",&n);

    int temp = n;

    while (temp!=0){
        reverse = reverse + (temp % 10);
        reverse = reverse * 10;
        temp = temp / 10;
    }
    reverse = reverse / 10;

    printf("Reverse: %d",reverse);

    if(reverse == n){
        printf("\nPalindrome\n");
    }
    else{
        printf("\nNot Palindrome\n");
    }
}

