#include<stdio.h>
int main()
{
    int temp, num, remainder, factorial = 0, i, sum=0;
    printf("Enter any number: ");
    scanf("%d",&num);

    temp = num;

    while(temp != 0)  //145
    {
        remainder = temp % 10;

        for(i=1; i<=remainder; i++)
        {
            factorial = factorial * i;
        }
        sum = factorial + sum;
        temp = temp / 10;

    }
    if(sum == num){
        printf("Strong");
    }
    else{
        printf("Not strong");
    }

}
