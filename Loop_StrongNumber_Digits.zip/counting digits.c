#include<stdio.h>
int main()
{
    int n,count=0;
    printf("Enter number: ");
    scanf("%d",&n);

    int temp = n;

    while(temp!=0){
        temp = temp / 10;
        count++;
    }
    printf("Count: %d",count);
}
