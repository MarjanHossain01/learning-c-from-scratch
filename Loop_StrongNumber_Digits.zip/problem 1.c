#include<stdio.h>
int main()
{
    int n,i,temp,j;
    printf ("Enter any Number: ");
    scanf("%d",&n);
    printf("I drive: ");
    for(i=2; i<=n; i++)
    {
        temp=0;
        for(j=1; j<n; j++)
        {
            if(i%j==0)
                temp++;
        }
        if(temp==2)
            printf("%d ",i);
    }
    return 0;
}
