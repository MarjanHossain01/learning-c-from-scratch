#include<stdio.h>
int main()
{
    int n, remainder, sum=0, temp;
    printf("Enter a number: ");
    scanf("%d",&n);
    temp = n;

    while(temp != 0){
    remainder = temp % 10;
    sum = sum + remainder;
    temp = temp / 10;
    }

    printf("%d",sum);

}
