#include<stdio.h>
int main ()
{
    char ch;
    printf("Enter character: ");
    scanf("%c", &ch);

    if (ch >= 'a' && ch <= 'z')
    {
        printf("Small");
    }
    else
    {
        printf("Capital");
    }
}
