#include<stdio.h>
int main()
{
    int n,i=0,s=0;
    printf("Enter a number: ");
    scanf("%d", &n);

    while(i <= n)
    {
        s+=i;
        i++;
    }
    printf("%d", s);
}
