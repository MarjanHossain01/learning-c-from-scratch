// start: 5.84
// switch keywords: switch, case, break, default

#include<stdio.h>
int main()
{

}
