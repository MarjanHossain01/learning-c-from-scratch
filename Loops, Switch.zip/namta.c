//Prime Number using while loop
#include<stdio.h>
int main()
{
    int n,i=2,count=0;
    printf("Enter a number: ");
    scanf("%d", &n);

    while(i<n)
    {
        if(n%i == 0){
            count++;
        }
        i++;
    }
    if(count != 0)
    {
        printf("%d is not Prime", n);
    }
    else
        printf("%d is Prime", n);


}
