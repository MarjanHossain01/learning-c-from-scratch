#include<stdio.h>
int main()
{
    int p;
    printf("Enter a number ");
    scanf("%d", &p);
    if(p >= 0)
    {
        printf("-%d", p);
    }
    else if (p < 0)
    {
        p = p - p;
        printf("%d", p);
    }
}
