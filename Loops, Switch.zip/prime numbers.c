#include<stdio.h>
int main()
{
    int n,i,r;
    printf("Enter a number: ");
    scanf("%d", &n);

    if (n % 2 == 0)
    {
        for(i=1; i<n; i++)
        {
            if(i % 2 == 0)
            {
                printf("%d\n", i);
                r = i + i;
            }
        }
        printf("Addition of the numbers are: %d\n", r);
    }


}
