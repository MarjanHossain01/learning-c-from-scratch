#include<stdio.h>
int main()
{
    int a,ap,f,p;
    float m;
    printf ("Enter marks ");
    scanf("%fg" ,&m);

    if(m >=80)
    {
        printf("A plus");
    }
    if(m >= 70 && m < 80)
    {
        printf("A");
    }
    if(m >= 60 && m < 70)
    {
        printf("A-");
    }
    else if (m < 32)
    {
        printf("fail");
    }
    return 0;
}
