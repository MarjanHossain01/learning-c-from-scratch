/*Control System
1) Conditional - If-else, Switch
2) Loop - loop lmao
*/

#include<stdio.h>
int main()
{
    int num1,num2;

    printf("Enter 1st number: ");
    scanf("%d", &num1);

    printf("Enter 2nd number: ");
    scanf("%d", &num2);

    if (num1 > num2)
        printf("%d is bigger than %d", num1, num2);
    else if (num1 < num2)
        printf("%d is bigger than %d", num2, num1);
    else
        printf("Numbers are equal");

    return 0;
}
