#include<stdio.h>
int a = 10;
int main()
{
    printf("a = %d\n", a);
    display();
}

void display()
{
    printf("a = %d", a);
}
