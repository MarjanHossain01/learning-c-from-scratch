#include<stdio.h>
int main()
{
    int n,s ,i;
    printf("Enter a number: ");
    scanf("%d", &n);

    do{
        ++i;
        s+=i;
    }
    while(i <= n);
    printf("%d", i);
}
