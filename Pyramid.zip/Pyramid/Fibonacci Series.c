//1 1 2 3 5 8 13 21 34....
#include<stdio.h>
int main()
{
    int n,row,col,sum,first=0,second=1;
    printf("Enter N: ");
    scanf("%d",&n);

    for(row=1;row<=n; row++){
        for(col=1; col<=n-row; col++){
            printf(" ");
        }
        for(col=1;col<=row;col++){
            sum = first + second;
            first = second;
            second = sum;
            printf(" %d",first);
        }
        printf("\n");
    }
}
