/*0 1 1 2 3 5 8 13 21 34....*/
#include<stdio.h>
int main()
{
    int n, first=0 , second=1, sum,i;
    printf("Enter N: ");
    scanf("%d",&n);
    for(i=1; i<=n; i++)
    {
        if(i>=2){
            sum = first + second;
            first = second;
            second = sum;
            printf("%d ",sum);
        }
        else{
        sum = first + second;
        printf("%d ",sum);
        }
    }

}
