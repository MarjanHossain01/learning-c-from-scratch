//2 1 3 4 7 11 18...
#include<stdio.h>
int main()
{
    int n,i,first=2,second=1,sum;
    printf("Enter N: ");
    scanf("%d",&n);

    printf("2 1 ");

    for(i=1; i<=n; i++)
    {
        if(i>=1)
        {
            sum = first + second;
            first = second;
            second = sum;
            printf("%d ",sum);
        }
    }
}
