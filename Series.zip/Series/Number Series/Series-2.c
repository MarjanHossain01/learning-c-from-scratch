#include<stdio.h>
int main()
{
    int n, sum=0,i=1;
    printf("Enter a number: ");
    scanf("%d",&n);

    while(i <= n){
        printf("%d ",i);
        sum = sum + i;
        i++;
    }
    printf("\nSum = %d",sum);
}
