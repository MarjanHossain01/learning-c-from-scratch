//1*2 2*3 3*4 4*5...n1*n2
#include<stdio.h>
int main()
{
    int n1,n2,sum=0,x=1,y=2;
    printf("Enter 2 numbers: ");
    scanf("%d",&n1);
    scanf("%d",&n2);

    while(x <= n1 && y <= n2){
        sum = sum + x * y;
        x = x+1;
        y = y+1;
    }

    printf("Sum: %d",sum);
}
