#include<stdio.h>
int main()
{
    int n, sum=1, i;
    printf("Enter a number: ");
    scanf("%d",&i);

    for(i=1; i<=n; i=i+2)
    {
        sum = sum * i*i*i;
    }
    printf("Sum: %d",sum);
}
