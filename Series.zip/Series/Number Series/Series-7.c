//Sum = 1-2+3-4+5....N
//Sum = (1+2+3+5) - (2+4)
#include<stdio.h>
int main()
{
    int n, i, odd=0, even=0;
    printf("Enter N: ");
    scanf("%d",&n);

    for(i=1; i<=n; i++)
    {
        if(i % 2 != 0)
        {
            odd = odd + i;
        }
        else{
        even = even + i;
        }
    }
    printf("Sum: %d",odd-even);
}
