#include <stdio.h>
int main()
{
    int num;
    scanf("%d", &num);
    printf("%d", num);
    return (0);
}
