#include<stdio.h>
int main()
{
   char low, high;
   scanf("%c", &high);
   low = tolower(high);
   printf("%c", low);
   return 0;
}
