#include<stdio.h>
int main(void)
{
    int num1;
    float num2;
    scanf("%d %f", &num1, &num2);
    printf("%d %f", num1, num2);
    return 0;
}
