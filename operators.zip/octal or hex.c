#include<stdio.h>
int main()
{
    int b,h;
    float a;
    printf("Enter Base: ");
    scanf("%d", &b);
    printf("Enter Height: ");
    scanf("%d", &h);
    a = (float) 1/2 * b * h;
    printf("%.1lf", a);
    return 0;
}
