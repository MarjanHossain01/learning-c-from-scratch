#include<stdio.h>
#include<math.h>
int main()
{
    double x,y,p;
    printf("Enter Lower number: ");
    scanf("%lf", &x);
    printf("Enter Power number: ");
    scanf("%lf", &y);
    p = pow(x,y);
    printf("%.1lf", p);
}
